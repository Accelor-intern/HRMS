import React from 'react';

// Create the AuthContext
export const AuthContext = React.createContext();