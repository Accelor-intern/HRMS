import { registerRootComponent } from 'expo';
import App from './index';

// Register the root component
registerRootComponent(App);
